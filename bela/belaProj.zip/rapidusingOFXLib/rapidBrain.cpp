/***** rapidBrain.cpp *****/
#include "rapidBrain.h"
/*
rapidBrain::rapidBrain(){
	
//myNN = 	new neuralNetwork<regression>(1, {0,1},1,2 );
}

void rapidBrain::addTrainingExample(float contKnob, float PitchKnob, float timbreKnob){
	
 trainingExample tempExample;
       // tempExample.input = {f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, f14};
        tempExample.input = {contKnob};
        tempExample.output = {PitchKnob, timbreKnob};
        trainingSet.push_back(tempExample);

}

void rapidBrain::addRunExample(float knobPos){
	
  		std::vector<double> input = {knobPos};
        std::vector<double> output = myRegression.process( input);
        // modulationFrequency = output[0];
        // modulationDepth = output[1];
        // centerFrequency = output[2];
        // resonance = output[3];

	
}
*/