#include <Bela.h>
#include <iostream>
#include "maximilian.h"
#include <math_neon.h>

AuxiliaryTask gPrintData;
void printData(void*);

maxiFilter filt;

float switchValue, sw2;
int gAudioFramesPerAnalogFrame;
bool setup(BelaContext *context, void *userData)
{
		gAudioFramesPerAnalogFrame = context->audioFrames / context->analogFrames;
	if((gPrintData= Bela_createAuxiliaryTask(&printData, 86, "printing")) == 0)
	return false;
		
	return true;
}

void render(BelaContext *context, void *userData)
{
	for(unsigned int n = 0; n < context->audioFrames; n++) {
	
		if(!(n % gAudioFramesPerAnalogFrame)) {
	switchValue = analogRead(context, n/gAudioFramesPerAnalogFrame, 4);
	sw2 = analogRead(context, n/gAudioFramesPerAnalogFrame, 5);
//switchValue =	floorf_neon(switchValue * 100.) / 100;
	if(!(n % (gAudioFramesPerAnalogFrame*10)))
		Bela_scheduleAuxiliaryTask(gPrintData);
		
		}
	}
}

void cleanup(BelaContext *context, void *userData)
{

}

void printData (void*){
		std::cout<< switchValue <<   " "<< sw2 << std::endl;
	
}