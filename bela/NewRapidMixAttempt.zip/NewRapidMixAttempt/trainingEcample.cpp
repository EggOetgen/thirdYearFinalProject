/***** trainingEcample.cpp *****/
