/***** buttonManage.h *****/
#include <Bela.h>

#define NUM_OF_BUTTONS 2;

class buttonManager{
	
	private:
	uint8_t buttons[NUM_OF_BUTTONS];
	public:
	checkButtons;
	
}